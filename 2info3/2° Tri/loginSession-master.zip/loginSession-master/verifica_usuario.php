<?php

	var_dump($_POST);
	exit();

	session_start();

	if () {
	
	} else {

	}