<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

	<div class="social">

		<a href="" class="sair">sair</a>

		<img src="http://www.laserskincare.ae/wp-content/uploads/2015/01/Untitled-3.jpg" alt="" width="200" height="200">
		<h3>Bem vindo!</h3>
	</div>

</body>
</html>